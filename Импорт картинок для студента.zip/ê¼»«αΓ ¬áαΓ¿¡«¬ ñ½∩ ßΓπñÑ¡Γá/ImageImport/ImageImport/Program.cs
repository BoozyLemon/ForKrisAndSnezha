﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageImport
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Вам нужно подключить в эту программу модель
             * ТОЧНО ТАК ЖЕ КАК И В WPF: Добавить -> Новый элемент -> Модель данных и т.д.
             */
            using (var db = new ВашаБаза())
            {
                var students = db.Students.ToList();
                foreach (var student in students)
                {
                    // Вот здесь путь к картинкам должен быть. В зависимости от того, что у вашего студента Nickname или Login выбираем
                    var path = $@"C:\Users\kusov\Desktop\task\Session 1\Import\images\{student.Login}.jpg";
                    if (File.Exists(path))
                        student.Photo = File.ReadAllBytes(path);
                }
            }
        }
    }
}
